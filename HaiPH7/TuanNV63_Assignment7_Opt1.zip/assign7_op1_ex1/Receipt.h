#ifndef DEF_RECEIPT
#define DEF_RECEIPT
#include <iostream>
#include "Customer.h"

class Receipt
{
	Customer m_customer;
	int m_oldNumber;
	int m_newNumber;
	int m_payment;
public:
	void input();
	void print();
	static void print_header();	// static method
	void print_row();
	void payment();
};


#endif // DEF_RECEIPT
