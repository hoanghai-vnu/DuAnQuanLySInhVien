#include "Customer.h"
using namespace std;

void Customer::input()
{
	cout << "Enter customer's info:" << endl;
	cout << "\tFull name: "; getline(cin, m_fullName);
	cout << "\tAddress: "; getline(cin, m_address);
	cout << "\tWatt-hour meter code: "; getline(cin, m_codeMeter);
}

void Customer::print()
{
	cout << "\nCustomer's info:" << endl;
	cout << "\tFull name: " << m_fullName << endl;
	cout << "\tAddress: " << m_address << endl;
	cout << "\tWatt-hour meter code: " << m_codeMeter << endl;
}

void Customer::print_header()
{
	printf("\n%-25s %-40s %-15s ", "Customer's_full_name", "Address", "Meter's_code");
}

void Customer::print_row()
{
	printf("%-25s %-40s %-15s ", m_fullName.c_str(), m_address.c_str(), m_codeMeter.c_str());
}
