#include "Receipt.h"
using namespace std;

// validate integer input
void input_integer(int &x)
{
	while(!(cin >> x))
	{
		cout << "Error: Please enter an integer number: ";
		cin.clear();
		cin.ignore(100, '\n');
	}
	cin.ignore(100, '\n');
}

void Receipt::input()
{
	m_customer.input();
	cout << "Enter electricity usage info:" << endl;
	cout << "\tOld number: "; input_integer(m_oldNumber);
	cout << "\tNew number: "; input_integer(m_newNumber);
	payment();
}

void Receipt::print()
{
	m_customer.print();
	cout << "Electricity usage info:" << endl;
	cout << "\tOld number: " << m_oldNumber << endl;
	cout << "\tNew number: " << m_newNumber << endl;
	cout << "Total payment: " << m_payment << " vnd" << endl;
}

void Receipt::print_header()
{
	Customer::print_header();
	printf("%-10s %-10s %-10s %-20s\n", "Old_number", "New_number", "Use_number", "Total_payment (vnd)");
	for(int i=0; i<83; i++)
		cout << '-';
	for(int i=0; i<53; i++)
		cout << '-';
	cout << endl;
}

void Receipt::print_row()
{
	m_customer.print_row();
	printf("%-10d %-10d %-10d %-20d\n", m_oldNumber, m_newNumber, (m_newNumber-m_oldNumber), m_payment);
}

void Receipt::payment()
{
	int useNumber = m_newNumber - m_oldNumber;
	if(useNumber < 50){
		m_payment = useNumber * 1250;
	} else if(useNumber < 100) {
		m_payment = 49*1250 + (useNumber-49)*1500;
	} else {
		m_payment = 49*1250 + 50*1500 + (useNumber-99)*2000;
	}
}
