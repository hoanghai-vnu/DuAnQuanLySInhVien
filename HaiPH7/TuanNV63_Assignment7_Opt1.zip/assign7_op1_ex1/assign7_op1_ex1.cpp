#include <iostream>
#include "Customer.h"
#include "Receipt.h"
using namespace std;

void task1()
{
	Customer customer;
	customer.input();
	customer.print();
}
void task2_3();

int main()
{
//	task1();
	task2_3();
	
    return 0;
}

void task2_3()
{
	int n;	// Number of households
	cout << "How many households do you want to enter information for? N = ";
	cin >> n; cin.ignore(100, '\n');
	
	Receipt *receiptList = new Receipt[n];
	for(int i=0; i<n; i++)
	{
		cout << "\nReceipt " << i+1 << ": " << endl;
		receiptList[i].input();
	}
	cout << "\nInformation about the receipts you entered:" << endl;
	Receipt::print_header();
	for(int i=0; i<n; i++)
	{
		receiptList[i].print_row();
	}
	
	delete[] receiptList;
}
