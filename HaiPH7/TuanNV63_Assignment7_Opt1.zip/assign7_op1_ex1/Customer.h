#ifndef DEF_CUSTOMER
#define DEF_CUSTOMER
#include <iostream>

class Customer
{
	std::string m_fullName;
	std::string m_address;
	std::string m_codeMeter;
public:
	void input();
	void print();
	static void print_header();	// static method
	void print_row();
};

#endif // DEF_CUSTOMER
