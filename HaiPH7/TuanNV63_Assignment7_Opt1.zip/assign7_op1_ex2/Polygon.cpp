#include "Polygon.h"
using namespace std;

Polygon::Polygon(): m_nSide(0), m_angles(NULL), m_sides(NULL) 
{}

Polygon::Polygon(int nSide): m_nSide(nSide), m_angles(new float[nSide]), 
m_sides(new int[nSide]) 
{}

// Free memory
Polygon::~Polygon()
{
	delete[] m_angles;
	delete[] m_sides;
}

// =============================================================================

int Polygon::perimeter()
{
	int perimeter = 0;
	for(int i=0; i<m_nSide; i++)
	{
		perimeter += m_sides[i];
	}
	return perimeter;
}

void Polygon::print_sides()
{
	for(int i=0; i<m_nSide; i++)
	{
		cout << m_sides[i] << " ";
	}
}
void Polygon::print_angles()
{
	for(int i=0; i<m_nSide; i++)
	{
		cout.precision(3);
		cout << m_angles[i] << " ";
	}
}

// =============================================================================

// validate integer input
void input_integer(int &x)
{
	while(!(cin >> x))
	{
		cout << "==> Error: Please enter an integer number: ";
		cin.clear();
		cin.ignore(100, '\n');
	}
	cin.ignore(100, '\n');
}

void Polygon::input()
{
	for(int i=0; i<m_nSide; i++)
	{
		cout << "Enter the dimension of edge " << i+1 << ": "; 
		input_integer(m_sides[i]);
	}
}
