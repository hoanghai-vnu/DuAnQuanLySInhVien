#ifndef DEF_TRIANGLE
#define DEF_TRIANGLE
#include <iostream>
#include <cmath>
#include "Polygon.h"

// Một tam giác xác định khi biết 3 cạnh

class Triangle: public Polygon
{
public:
	Triangle(): Polygon(3) {};
	Triangle(int a, int b, int c);	// Using for calculate the area of quadrilateral
	int perimeter();	// This is required 
	float area();
	
	void input(); 	// Overriding to check if the 3 entered edges are satisfied
	bool isPitagoTri();
};

#endif // DEF_TRIANGLE
