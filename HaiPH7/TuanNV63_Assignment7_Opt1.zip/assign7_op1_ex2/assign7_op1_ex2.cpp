#include <iostream>
#include "Triangle.h"
#include "Quadrilateral.h"
using namespace std;

void testTri();
void testQuad();
void mainTask();

int main()
{
//	testTri();
//	testQuad();
	mainTask();
	
    return 0;
}

void testTri()
{
	cout << "\nTest Triangle class" << endl;
	Triangle t;
	t.input();
	cout << "\nPerimeter: " << t.perimeter() << endl;
	cout << "Area: " << t.area() << endl;
}

void testQuad()
{
	cout << "\nTest Quadrilateral class" << endl;
	Quadrilateral q;
	q.input();
	cout << "\nPerimeter: " << q.perimeter() << endl;
	cout << "Area: " << q.area() << endl;
}

void mainTask()
{
	int n;
	cout << "Number of triangles you want to enter: ";
	cin >> n;
	
	Triangle *listTri = new Triangle[n];
	// input from keyboard
	for(int i=0; i<n; i++)
	{
		cout << "Triangle " << i+1 << ":" << endl;
		listTri[i].input();
		cout << endl;
	}
	// check if any triangle satisfies Pitago
	cout << "Triangles satisfied Pitago you entered:: " << endl;
	for(int i=0; i<n; i++)
	{
		if(listTri[i].isPitagoTri())	// lvalue in the left
		{
			listTri[i].print_sides();
			cout << endl;
		}
	}
	
	delete[] listTri; 	// free
}
