#ifndef DEF_QUADRILATERAL
#define DEF_QUADRILATERAL
#include <iostream>
#include <cmath>
#include "Polygon.h"
#include "Triangle.h"	// Using for calculate the area of quadrilateral

/* Một tứ giác (giả sử chỉ xét tứ giác lồi) xác định khi biết:
	+ các cạnh
	+ 1 góc đối diện hoặc 1 đường chéo
*/

class Quadrilateral: public Polygon
{
	int m_diag;	// diagonal line - assuming opposite edge has index 0 and 1
public:
	Quadrilateral(): Polygon(4), m_diag(0) {};
	int perimeter();
	float area();
	
	void input();	// Overriding to check if the 4 entered edges are satisfied
};

#endif // DEF_QUADRILATERAL
