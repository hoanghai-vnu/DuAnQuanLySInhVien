#ifndef DEF_POLYGON
#define DEF_POLYGON
#include <iostream>

class Polygon
{
protected:
	int m_nSide;	// number of sides
	float* m_angles;	// will point to the dynamically allocated array
	int* m_sides;	// will point to the dynamically allocated array
public:
	Polygon();
	Polygon(int nSide);
	~Polygon();
	
	int perimeter();
	void print_sides();
	void print_angles();
	
	void input();
};

void input_integer(int &x);	// Input and validate input function for integer

#endif // DEF_POLYGON
