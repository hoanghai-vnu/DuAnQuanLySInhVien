#include "Quadrilateral.h"
using namespace std;

int Quadrilateral::perimeter()
{
	return (m_sides[0] + m_sides[1] + m_sides[2] + m_sides[3]);
}

/* Cach tinh dien tich tu giac
	Chia tu giac thanh 2 tam giac
	Tu giac co cac canh la 1 2 3 4 thi canh 1 2 va 4 3 
	se tao thanh 2 tam giac co canh chung là m_diag
	Dien tich tu giac bang tong dien tich 2 tam giac nay
*/

float Quadrilateral::area()
{
	Triangle tri1(m_sides[0], m_sides[1], m_diag);
	Triangle tri2(m_sides[2], m_sides[3], m_diag);
	
	return (tri1.area() + tri2.area());
}

// =============================================================================

void Quadrilateral::input()
{
	// Input edges
	int a, b, c, d;
	bool check = false;
	do{
		Polygon::input();
		a = m_sides[0];
		b = m_sides[1];
		c = m_sides[2];
		d = m_sides[3];
		// The sum of any three sides of a quadrilateral 
		// is always greater than the fourth side.
		if(!(a+b+c>d && b+c+d>a && c+a+b>d && d+a+b>c))
		{
			cout << "==> You just entered not satisfying 4 sides ";
			cout << "1 quadrilateral. Please re-enter:" << endl;
			check = true;
		} else {
			check = false;
		}
	} while(check);
	
	// Input diagonal line
	do{
		cout << "\nEnter diagonal line that opposite edge has index 0 and 1: ";
		input_integer(m_diag);
		a = m_sides[0];
		b = m_sides[1];
		int e = m_diag;
		c = m_sides[2];
		d = m_sides[3];
		
		// m_diag cũng phải tạo thành tam giác với 2 cặp cạnh đối kề nó.
		if(!(a+b>e && b+e>a && e+a>b))
		{
			cout << "==> Entered diagonal line cannot form a triangle" << endl;
			cout << "\twith sides with index 0 and 1. Please re-enter: " << endl;
			check = true;
			continue;	// Must be satisfied
		}else {
			check = false;
		}
		
		if (!(c+d>e && d+e>c && e+c>d)) {
			cout << "==> Entered diagonal line cannot form a triangle" << endl;
			cout << "\twith sides with index 2 and 3. Please re-enter: " << endl;
			check = true;
		}else {
			check = false;
		}
	} while(check);
}
