#include "Triangle.h"
using namespace std;

Triangle::Triangle(int a, int b, int c): Polygon(3)
{
	m_sides[0] = a;
	m_sides[1] = b;
	m_sides[2] = c;
}

int Triangle::perimeter()
{
	return (m_sides[0] + m_sides[1] + m_sides[2]);
}

float Triangle::area()
{
	float p = (float)perimeter()/2.0;	// Tránh chia nguyên
	float area2 = p;
	for(int i=0; i<3; i++)
		area2 *= (p - m_sides[i]);
	return sqrt(area2);
}

// =============================================================================

void Triangle::input()
{
	int a, b, c;	// to acess by while
	do{
		Polygon::input();
		a = m_sides[0];
		b = m_sides[1];
		c = m_sides[2];
// The sum of any two sides of a triangle is always greater than the third side.
		if(!(a+b>c && b+c>a && c+a>b))
		{
			cout << "==> You just entered not satisfying 3 sides 1 triangle.";
			cout << " Please re-enter!" << endl;
		}
	} while(!(a+b>c && b+c>a && c+a>b));
}

bool Triangle::isPitagoTri()
{
	bool result = false;
	int x = pow(m_sides[0], 2);
	int y = pow(m_sides[1], 2);
	int z = pow(m_sides[2], 2);
	if(x+y == z || y+z == x || z+x == y)	// lvalue in the left
	{
		result = true;
	}
	return result;
}
