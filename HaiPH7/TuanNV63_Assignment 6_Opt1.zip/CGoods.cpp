#include "CGoods.h"
using namespace std;

void CGoods::input()
{
	cout << "The value is expressed in units of dong" << endl;
	cout << "Input code : "; cin.getline(m_cCode, 4);
	cout << "Input name : "; cin.getline(m_cName, 20);
	cout << "Input unit to calculate : "; cin.getline(m_cUnit, 10);
	cout << "Input unit price : ";
	// validate a float input
	while(!(cin >> m_fUPrice))
	{
		// inform error
		cout << "Error: Please enter a float number: ";
		// to get rid of the error flag
		cin.clear();
		// extracts characters from the input sequence and discards them
		cin.ignore(100, '\n');
	}
	
	cout << "Input number of good : ";
	// validate an int input
	while(!(cin >> m_nNumberOfGood))
	{
		cout << "Error: Please enter an integer number: ";
		cin.clear();
		cin.ignore(100, '\n');
	}
}

void CGoods::payment()
{
	m_fValue = m_nNumberOfGood * m_fUPrice;
}

void CGoods::info() const
{
	cout << "Entered code : " << m_cCode << endl; 
	cout << "Entered name : " << m_cName << endl; 
	cout << "Entered unit to calculate : " << m_cUnit << endl; 
	cout << "Entered unit price : " << m_fUPrice << endl;
	cout << "Entered number of good : " << m_nNumberOfGood << endl;
}

void Goods::input()
{
	CGoods::input();
	cout << "Input shipping unit price : ";
	// validate an int input
	while(!(cin >> m_fShippingUnitPrice))
	{
		cout << "Error: Please enter a float number: ";
		cin.clear();
		cin.ignore(100, '\n');
	}
}

void Goods::transportationCosts()
{
	m_fTransCost = m_nNumberOfGood * m_fShippingUnitPrice;
}

float Goods::payment()
{
	CGoods::payment();
	return (m_fValue + m_fTransCost);
}

void Goods::info() const
{
	CGoods::info();
	cout << "Entered shipping unit price : " << m_fShippingUnitPrice << endl;
}
