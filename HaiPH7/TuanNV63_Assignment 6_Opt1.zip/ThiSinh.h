#ifndef DEF_CGOODS
#define DEF_CGOODS
#include <iostream>
#include <fstream>

typedef struct {
	std::string ho;
	std::string tenDem;
	std::string ten;	
} HoTen;

typedef struct {
	std::string xa;
	std::string huyen;
	std::string tinh;	
} QueQuan;

typedef struct {
	float toan;
	float ly;
	float hoa;	
} DiemThi;

class ThiSinh
{
	HoTen m_hoTen;
	QueQuan m_queQuan;
	std::string m_truong;
	int m_tuoi;
	std::string m_SBD;
	DiemThi m_diemThi;
	
public:
	// Default constructor to create a object without pass anything
	ThiSinh();

	void type_input();
	void file_input(std::ifstream& readFile);
	
	void print_header() const;
	void print_row() const;
	void print_row2() const;
	
	float tinhTongDiem() const;
};


#endif //DEF_CGOODS
