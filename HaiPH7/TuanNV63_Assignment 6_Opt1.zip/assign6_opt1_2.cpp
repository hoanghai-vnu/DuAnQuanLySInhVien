#include<iostream>
#include"ThiSinh.h"
using namespace std;

int main()
{
	ThiSinh tuan;
	int n=0;	// So luong thi sinh
	ThiSinh *dsThiSinh;
	
	// task 1
//	tuan.type_input();
//	tuan.print_header();
//	tuan.print_row();
	
	// task 2:
	// Tao danh sach sinh vien - còn hơi thô
	cout << "Nhap so luong thi sinh: "; cin >> n;
	dsThiSinh = new ThiSinh[n];
	ifstream readFile("assign6_opt1_data.txt");
	tuan.print_header();
	if(readFile)
	{
		for(int i=0; i<n; i++)
			dsThiSinh[i].file_input(readFile);
	} 
	else
	{
		cout << "Could not open assign6_opt1_data.txt data file to read." << endl;
	}
	// In danh sach sinh vien doc tu file ra man hinh
	for(int i=0; i<n; i++)
		dsThiSinh[i].print_row();
		
	// task 3:
	cout << "\nDanh sach thi sinh co tong diem 3 mon lon hon 15 la:" << endl;
	tuan.print_header();
	for(int i=0; i<n; i++)
	{
		if(dsThiSinh[i].tinhTongDiem() > 15)
			dsThiSinh[i].print_row();
	}
	
	// task 4:
	cout << "\nDanh sach thi sinh co tong diem 3 mon theo thu tu giam dan:" << endl;
	ThiSinh **plist = new ThiSinh*[n];
	for(int i=0; i<n; i++)
		plist[i] = &(dsThiSinh[i]);
	for(int i=0; i<n-1; i++)
		for(int j=i+1; j<n; j++)
			if((plist[i])->tinhTongDiem() < (plist[j])->tinhTongDiem())
			{
				ThiSinh *temp = plist[i];
				plist[i] = plist[j];
				plist[j] = temp;
			}
	for(int i=0; i<n; i++)
		plist[i]->print_row2();
	
    return 0;
}
