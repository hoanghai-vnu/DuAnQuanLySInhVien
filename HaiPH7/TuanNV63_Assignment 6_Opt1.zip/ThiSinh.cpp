#include "ThiSinh.h"
using namespace std;

void input_integer(int &x)
{
	while(!(cin >> x))
	{
		cout << "Error: Please enter an integer number: ";
		cin.clear();
		cin.ignore(100, '\n');
	}
}

void input_float(float &x)
{
	while(!(cin >> x))
	{
		cout << "Error: Please enter a float number: ";
		cin.clear();
		cin.ignore(100, '\n');
	}
}

void nhapDiemThi(float &x)
{
	input_float(x);
	while(!(0 <= x && x <= 10))
	{
		cout << "Tuoi phai nam trong pham vi (0-10): ";
		input_float(x);
	}
}

ThiSinh::ThiSinh(){}

void ThiSinh::type_input()
{
	// Nhập họ tên
	cout << "Nhap ho va ten:" << endl;
	cout << "\tNhap ho: "; getline(cin, m_hoTen.ho);	
	cout << "\tNhap ten dem: "; getline(cin, m_hoTen.tenDem);
	cout << "\tNhap ten: "; getline(cin, m_hoTen.ten);
	// Nhập quê quán
	cout << "Nhap que quan:" << endl;
	cout << "\tNhap xa: "; getline(cin, m_queQuan.xa);	
	cout << "\tNhap huyen: "; getline(cin, m_queQuan.huyen);
	cout << "\tNhap tinh: "; getline(cin, m_queQuan.tinh);
	// Nhập trường, tuổi, số báo danh
	cout << "Nhap thong tin khac:" << endl;
	cout << "\tNhap truong: "; getline(cin, m_truong);
	cout << "\tNhap tuoi cua ban: ";
	input_integer(m_tuoi);
	while(!(5<m_tuoi && m_tuoi < 80))
	{
		cout << "Tuoi phai nam trong pham vi (5-80): ";
		input_integer(m_tuoi);
	}
	cin.ignore();
	cout << "\tNhap so bao danh: "; getline(cin, m_SBD);
	// Nhập điểm thi
	cout << "Nhap diem thi:" << endl;
	cout << "\tDiem mon Toan: "; nhapDiemThi(m_diemThi.toan);
	cout << "\tDiem mon Ly: "; nhapDiemThi(m_diemThi.ly);
	cout << "\tDiem mon Hoa: "; nhapDiemThi(m_diemThi.hoa);
}

void ThiSinh::file_input(std::ifstream& readFile)
{
		getline(readFile, m_hoTen.ho);
		getline(readFile, m_hoTen.tenDem);
		getline(readFile, m_hoTen.ten);
		// Nhập quê quán
		getline(readFile, m_queQuan.xa);	
		getline(readFile, m_queQuan.huyen);
		getline(readFile, m_queQuan.tinh);
		// Nhập trường, tuổi, số báo danh
		getline(readFile, m_truong);
		readFile >> m_tuoi; readFile.ignore(100, '\n');
		getline(readFile, m_SBD);
		// Nhập điểm thi
		readFile >> m_diemThi.toan; readFile.ignore(100, '\n');
		readFile >> m_diemThi.ly; readFile.ignore(100, '\n');
		readFile >> m_diemThi.hoa; readFile.ignore(100, '\n');
}

void ThiSinh::print_header() const
{
	printf("\n%-25s %-40s %-20s %-8s %-10s %-5s %-5s %-5s\n", "Ho va ten","Que quan","Truong","Tuoi","SBD","Toan","Ly","Hoa");
	for(int i=0; i<125; i++)
		cout << '-';
	cout << endl;
}

void ThiSinh::print_row() const
{
	printf("%-25s %-40s %-20s %-8d %-10s %-5.2f %-5.2f %-5.2f\n", (m_hoTen.ho + " " + m_hoTen.tenDem + " " + m_hoTen.ten).c_str(), (m_queQuan.xa + ", " + m_queQuan.huyen + ", " + m_queQuan.tinh).c_str(), m_truong.c_str(), m_tuoi, m_SBD.c_str(), m_diemThi.toan, m_diemThi.ly, m_diemThi.hoa);
}

void ThiSinh::print_row2() const
{
	printf("%-25s %-40s %-10s %-5.2f %-5.2f %-5.2f\n", (m_hoTen.ho + " " + m_hoTen.tenDem + " " + m_hoTen.ten).c_str(), (m_queQuan.xa + ", " + m_queQuan.huyen + ", " + m_queQuan.tinh).c_str(), m_SBD.c_str(), m_diemThi.toan, m_diemThi.ly, m_diemThi.hoa);
}

float ThiSinh::tinhTongDiem() const
{
	return (m_diemThi.toan + m_diemThi.ly +m_diemThi.hoa);
}
