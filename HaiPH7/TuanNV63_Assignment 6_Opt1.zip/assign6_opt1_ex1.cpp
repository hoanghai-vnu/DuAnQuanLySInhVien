#include<iostream>
#include"CGoods.h"
using namespace std;

int main()
{
	Goods good;
	good.input();
	cout << endl;
	// In lại các giá trị vừa nhập để xác nhận thông tin
	good.info();
	
	// Sử dụng hai phương thức yêu cầu
	good.transportationCosts();
	cout << "\nTotal amount: " << good.payment() << " dong" << endl;
	
    return 0;
}
