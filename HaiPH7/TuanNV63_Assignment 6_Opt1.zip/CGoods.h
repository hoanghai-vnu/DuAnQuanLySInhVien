#ifndef DEF_CGOODS
#define DEF_CGOODS
#include <iostream>

class CGoods
{
protected:
	char m_cCode[4];	// mã code i.e: C50
	char m_cName[20];	// tên hàng i.e móc quần áo
	char m_cUnit[10];	// đơn vị tính i.e set (10 cái)
	float m_fUPrice, m_fValue;	// đơn giá (27k/set) và thành tiền 2*27 = 54k
	int m_nNumberOfGood; // số lượng i.e 2 set
public:	
	void input();
	void payment();
	void info() const;
};

class Goods : public CGoods
{
	float m_fShippingUnitPrice, m_fTransCost; // đơn giá vận chuyển, phí vận chuyển
public:
	void input();
	void transportationCosts();
	float payment();
	void info() const;
};

#endif //DEF_CGOODS
